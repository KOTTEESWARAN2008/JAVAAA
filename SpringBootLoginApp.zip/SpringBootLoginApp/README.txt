SPRING BOOT LOGIN APP

Demo username: ADMIN
Demo password: ADMIN

Requirements: JDK 17+ and Maven 3.6.3+.

Run on Windows:
1. Extract this ZIP.
2. Open CMD in the SpringBootLoginApp folder (the folder containing pom.xml).
3. Check: java -version
4. Check: mvn -version
5. Run: mvn spring-boot:run
   First run requires internet to download Maven dependencies.
6. Open http://localhost:8080 in Chrome.
7. Enter ADMIN / ADMIN.

Correct login: LOG IN SUCCESS
Wrong login: LOGIN FAILED

This is a learning demo with hard-coded credentials, not production authentication.
